package edu.stanford.cs108.assign5;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public class Cracker {
	// Array of chars used to produce strings
	public static final char[] CHARS = "abcdefghijklmnopqrstuvwxyz0123456789.,-!".toCharArray();	
	private static List<String> list = Collections.synchronizedList(new ArrayList<String>());
	private static String password;
	private static byte[] hash;
	private static int maximumLength;
	private static int numberOfThreads;
	private static CountDownLatch latch;
	
	public static class Worker extends Thread {
		private int firstChar;
		private int lastChar;
		
		public Worker(int f, int l) {
			this.firstChar = f;
			this.lastChar = l;
		}
		@Override
		public void run() {
			String hashString = "";
			int counter= 1;
			turing(hashString, counter);
			latch.countDown();
		}
		private void turing(String comparisonString, int counter) {
			if(counter > maximumLength) { // If number of iterations exceeds maximum length it will abort
				return;
			}
			if(counter == 1) {
				for(int c = firstChar; c < lastChar; c++) {
					String currentComparisonString = turingHelper(comparisonString, c);
					turing(currentComparisonString, counter + 1);
				}
			} else {
				for(int c = 0; c < CHARS.length; c++) {
					String currentComparisonString = turingHelper(comparisonString, c);
					turing(currentComparisonString, counter + 1);
				}
			}
		}
	}
	public static String turingHelper(String comparisonString, int c) {
		String currentComparisonString = comparisonString + CHARS[c];
		byte[] testHash = makePassword(currentComparisonString);
		if(Arrays.equals(hash, testHash)) {
			list.add(currentComparisonString);
		}
		return currentComparisonString;
	}
	
	
	public static byte[] makePassword(String password) {
		byte[] result = null;
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			result = messageDigest.digest(password.getBytes()); // Convert password into hash
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/*
	 Given a byte[] array, produces a hex String,
	 such as "234a6f". with 2 chars for each byte in the array.
	 (provided code)
	*/
	public static String hexToString(byte[] bytes) {
		StringBuffer buff = new StringBuffer();
		for (int i=0; i<bytes.length; i++) {
			int val = bytes[i];
			val = val & 0xff;  // remove higher bits, sign
			if (val<16) buff.append('0'); // leading 0
			buff.append(Integer.toString(val, 16));
		}
		return buff.toString();
	}
	
	/*
	 Given a string of hex byte values such as "24a26f", creates
	 a byte[] array of those values, one byte value -128..127
	 for each 2 chars.
	 (provided code)
	*/
	public static byte[] hexToArray(String hex) {
		byte[] result = new byte[hex.length()/2];
		for (int i=0; i<hex.length(); i+=2) {
			result[i/2] = (byte) Integer.parseInt(hex.substring(i, i+2), 16);
		}
		return result;
	}
	
	public static void main(String[] args) {
		if(args.length == 1) {	// Convert password to hash			
			password = args[0];
			byte[] hashByte = makePassword(password);
			System.out.println(hexToString(hashByte));
		
		} else if(args.length == 3) { // Use brute force to try and crack the hash in order to find password
			numberOfThreads = Integer.parseInt(args[2]);
			maximumLength = Integer.parseInt(args[1]);
			hash = hexToArray(args[0]);
			latch = new CountDownLatch(numberOfThreads);	
			
			createAndStartThreads();
			prepareLatch(latch);
			
		} else {	
			System.err.println("Error: The number of arguments must be 1 or 3");
		}
	}
	
	public static void createAndStartThreads() {
		int segment = (int) Math.ceil(((double) CHARS.length) / numberOfThreads);
		Worker[] threads = new Worker[numberOfThreads];
		for(int c = 0; c < numberOfThreads - 1; c++) {
			threads[c] = new Worker(c * segment, (c + 1) * segment);
		}
		threads[numberOfThreads - 1] = new Worker((numberOfThreads - 1) * segment, CHARS.length);
		for(int c = 0; c < numberOfThreads; c++) {
			threads[c].start();
		}
	}
	
	public static void prepareLatch(CountDownLatch latch) {
		try {
			latch.await();
			for (int c = 0; c < list.size(); c++) {
				System.out.println(list.get(c));
			}
			System.out.println("QED");
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 
	}
	
	// possible test values:
	// a ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb
	// fm 440f3041c89adee0f2ad780704bcc0efae1bdb30f8d77dc455a2f6c823b87ca0
	// a! 242ed53862c43c5be5f2c5213586d50724138dea7ae1d8760752c91f315dcd31
	// xyz 3608bca1e44ea6c4d268eb6db02260269892c0b42b86bbf1e77a6fa16c3c9282

}
