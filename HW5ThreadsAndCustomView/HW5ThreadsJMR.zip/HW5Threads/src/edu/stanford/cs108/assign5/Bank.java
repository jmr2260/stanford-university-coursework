package edu.stanford.cs108.assign5;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Bank {

	private static Account[] accountArray;
	private final static int numberOfAccounts = 20;
	private static ArrayBlockingQueue<Transaction> blockingQueue;
	private final static int blockingQueueLength = 50;
	private static CountDownLatch latch;
	private static Worker[] threads;
	private static int numberOfThreads;
	private final static int balanceToStart = 1000;
	private final static int transactionToStart = 0;

	public static void main(String[] args) {
		// Create individual accounts
		accountArray = new Account[numberOfAccounts];
		for(int c = 0; c < numberOfAccounts; c++) {
			accountArray[c] = new Account(c, balanceToStart, transactionToStart);
		}
		// Create blockingQueue
		blockingQueue = new ArrayBlockingQueue<Transaction>(blockingQueueLength);
		numberOfThreads = Integer.parseInt(args[1]);
		threads = makeThreads(numberOfThreads);
		latch = new CountDownLatch(numberOfThreads);
		
		for(int c = 0; c < numberOfThreads; c++)  {
			threads[c].start();
		}
		
		// Read the ledger file
		readLedger(args[0]); // Individual threads will now read the ledger file

		try {
			latch.await();
			transactionSummary();
		} catch (InterruptedException interruptedException) {
			interruptedException.printStackTrace();
		}     
	}
	
	private static void transactionSummary() {
		for(int c = 0; c < numberOfAccounts; c++) {
			System.out.println(accountArray[c]);
		}
	}
	
	private static Worker[] makeThreads(int t) {
		threads = new Worker[t];
		for(int c = 0; c < t; c++) {
			threads[c] = new Worker();
		}
		return threads;
	}

	private static void readLedger(String fileName) {
		try {

			FileReader ledgerReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(ledgerReader);
			Scanner scanner = new Scanner(bufferedReader);
			while (scanner.hasNext()) {
				int origin = scanner.nextInt();
				int destination = scanner.nextInt();
				int money = scanner.nextInt();
				Transaction payment = new Transaction(origin, destination, money);
				try {
					blockingQueue.put(payment);
				} catch (InterruptedException interruptedException) {
					interruptedException.printStackTrace();
				}
			}
			scanner.close();
			bufferedReader.close();
			ledgerReader.close();
			
			Transaction nullTrans = new Transaction(-1, 0, 0);
			for(int i = 0; i < numberOfThreads; i++) {
				try {
					blockingQueue.put(nullTrans);
				} catch (InterruptedException interruptedException) {
					interruptedException.printStackTrace();
				}
			}
		}
		catch(FileNotFoundException interruptedException) {
			interruptedException.printStackTrace();
		}
		catch(IOException interruptedException) {
			interruptedException.printStackTrace();
		}
	}

	public static class Worker extends Thread {
		
		@Override
		public void run() {
			while(true) {
				Transaction payment;
				try {
					payment = blockingQueue.take();
					if(payment.getPayer() != -1) {
						makePayment(payment);
					} else {
						latch.countDown();
						break;
					}
				} catch (InterruptedException interruptedException) {
					interruptedException.printStackTrace();
				}
			}
		}
		
		public void makePayment(Transaction payment) {
			Account payer = accountArray[payment.getPayer()];
			Account payee = accountArray[payment.getPayee()];
			int money = payment.getMoney();
			payer.payment(payee, money);
		}	
	}
}