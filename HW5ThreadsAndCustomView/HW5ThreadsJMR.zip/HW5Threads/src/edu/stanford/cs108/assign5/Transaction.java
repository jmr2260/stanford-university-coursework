package edu.stanford.cs108.assign5;

public class Transaction {

	private int money; // money will be debited from payer and credited to payee
	private int payer;
	private int payee;
	
	public Transaction(int o, int d, int m) {
		this.payer = o;
		this.payee = d;
		this.money = m;
	}
	
	public int getPayer() {
		return payer;
	}
	
	public int getPayee() {
		return payee;
	}
	
	public int getMoney() {
		return money;
	}
}