package edu.stanford.cs108.assign5;

public class Account {
	
	protected int transactionNumber;
	protected int accountNumber;
	protected int accountBalance;
	private static Object lock = new Object();
	
	public Account(int an, int ab, int tn) {
		this.accountNumber = an;
		this.accountBalance = ab;
		this.transactionNumber = tn;
	}
	
	public void payment(Account that, int money) {
		synchronized(lock) {
			this.accountBalance -= money;
			that.accountBalance += money;
			this.transactionNumber += 1;
			that.transactionNumber += 1;
		}
	}
	
	@Override
	public String toString() {
		String transactionString = "";
		transactionString += "acct:" + accountNumber + " bal:" + accountBalance + " trans:" + transactionNumber;
		return transactionString;
	}
}