package edu.stanford.cs108.mobiledraw;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import java.util.*;

public class CustomViewActivity extends View {
    protected static int userSelectedOption = 1;
    protected static int currentShapeIndex = -1; //
    protected static int selectIndex, eraseIndex; //
    protected static boolean selectOrErase = false; //
    protected static float initialX,initialY,finalX,finalY,selectedX,selectedY; //
    protected static float height, width, cornerTop, cornerLeft, cornerBottom, cornerRight; //
    protected Paint whiteUnselected, redUnselected, whiteSelected, blueSelected;
    protected static List<RectF> shapeCoordinateArray = new ArrayList<RectF>();
    protected static List<Boolean> shapeBoolean = new ArrayList<Boolean>();

    public CustomViewActivity(Context context, AttributeSet attrs) {
        super(context, attrs);

        whiteSelected = new Paint();
        whiteSelected.setColor(Color.rgb(255,255,255));
        whiteSelected.setStyle(Paint.Style.FILL);

        whiteUnselected = new Paint();
        whiteUnselected.setColor(Color.rgb(255,255,255));
        whiteUnselected.setStyle(Paint.Style.FILL);

        blueSelected = new Paint();
        blueSelected.setColor(Color.rgb(130,170,255));
        blueSelected.setStyle(Paint.Style.STROKE);
        blueSelected.setStrokeWidth(15.0f);

        redUnselected = new Paint();
        redUnselected.setColor(Color.rgb(200,10,10));
        redUnselected.setStyle(Paint.Style.STROKE);
        redUnselected.setStrokeWidth(5.0f);
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (userSelectedOption == 0) {
            if(!selectOrErase) {
                selectIndex = identifyShape();
            }
            selectOrErase = false;
            populateBottomBar(selectIndex);
            currentShapeIndex = selectIndex;
            drawSelect(canvas, selectIndex);
        } else if (userSelectedOption == 1) {
            drawShape(canvas, false);
        } else if (userSelectedOption == 2) {
            drawShape(canvas, true);
        } else if (userSelectedOption == 3) {
            if(!selectOrErase) {
                eraseIndex = identifyShape();
            }
            selectOrErase = false;
            if(eraseIndex >= 0) {
                shapeCoordinateArray.remove(eraseIndex);
                shapeBoolean.remove(eraseIndex);
            }
            populateBottomBar(-1);
            drawSelect(canvas, -1);
        } else {
            System.err.println("Error: no such option exists.");
        }
    }
    protected void drawShape(Canvas canvas, boolean shapeChoice) {
        RectF shape = new RectF(cornerLeft, cornerTop, cornerRight, cornerBottom);
        shapeCoordinateArray.add(shape);
        shapeBoolean.add(shapeChoice);
        currentShapeIndex = shapeCoordinateArray.size() - 1;
        populateBottomBar(shapeCoordinateArray.size() - 1);
        drawSelect(canvas, shapeCoordinateArray.size() - 1);
    }
    private void populateBottomBarHelper(String[] coordinateString) {
        EditText editTextFirstField = (EditText) ((Activity) getContext()).findViewById(R.id.firstField);
        editTextFirstField.setText(coordinateString[0]);
        EditText editTextSecondField = (EditText) ((Activity) getContext()).findViewById(R.id.secondField);
        editTextSecondField.setText(coordinateString[1]);
        EditText editTextFourthField = (EditText) ((Activity) getContext()).findViewById(R.id.fourthField);
        editTextFourthField.setText(coordinateString[2]);
        EditText editTextThirdField = (EditText) ((Activity) getContext()).findViewById(R.id.thirdField);
        editTextThirdField.setText(coordinateString[3]);
    }
    private void populateBottomBar(int index) {
        if(index >= 0 && (userSelectedOption <= 2)) {
            height = shapeCoordinateArray.get(index).bottom - shapeCoordinateArray.get(index).top;
            width = shapeCoordinateArray.get(index).right - shapeCoordinateArray.get(index).left;

            String[] coordinateString = new String[4];
            coordinateString[0] = Float.toString(shapeCoordinateArray.get(index).left);
            coordinateString[1] = Float.toString(shapeCoordinateArray.get(index).top);
            coordinateString[2] = Float.toString(height);
            coordinateString[3] = Float.toString(width);
            populateBottomBarHelper(coordinateString);

        } else {
            String[] coordinateString = new String[] {"", "", "", "", ""};
            populateBottomBarHelper(coordinateString);

        }
    }
    private int identifyShape() {
        int index = Integer.MIN_VALUE;
        for(int c = shapeCoordinateArray.size() - 1; c >= 0 ; c--) {
            RectF currentShape = shapeCoordinateArray.get(c);
            if(currentShape.top <= selectedY && selectedY <= currentShape.bottom && currentShape.left <= selectedX && selectedX <= currentShape.right) {
                index = c;
                break;
            }
        }
        return index;
    }
    protected void drawSelect(Canvas canvas, int index) {
        for(int c = 0; c < shapeCoordinateArray.size(); c++) {
            if(!shapeBoolean.get(c)) {
                if(c != index) {
                    canvas.drawRect(shapeCoordinateArray.get(c), whiteUnselected);
                    canvas.drawRect(shapeCoordinateArray.get(c), redUnselected);
                } else {
                    canvas.drawRect(shapeCoordinateArray.get(c), whiteSelected);
                    canvas.drawRect(shapeCoordinateArray.get(c), blueSelected);
                }
            } else {
                if(c != index) {
                    canvas.drawOval(shapeCoordinateArray.get(c), whiteUnselected);
                    canvas.drawOval(shapeCoordinateArray.get(c), redUnselected);
                } else {
                    canvas.drawOval(shapeCoordinateArray.get(c), whiteSelected);
                    canvas.drawOval(shapeCoordinateArray.get(c), blueSelected);
                }
            }
        }

    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        RadioButton firstButton = (RadioButton)((Activity)getContext()).findViewById(R.id.firstButton);
        RadioButton secondButton = (RadioButton)((Activity)getContext()).findViewById(R.id.secondButton);
        RadioButton thirdButton = (RadioButton)((Activity)getContext()).findViewById(R.id.thirdButton);
        RadioButton fourthButton = (RadioButton)((Activity)getContext()).findViewById(R.id.fourthButton);

        if(firstButton.isChecked()) {
            userSelectedOption = 0;
        } else if(secondButton.isChecked()) {
            userSelectedOption = 1;
        } else if(thirdButton.isChecked()) {
            userSelectedOption = 2;
        } else if(fourthButton.isChecked()) {
            userSelectedOption = 3;
        }
        if (userSelectedOption == 0 || userSelectedOption == 3) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                selectedX = event.getX();
                selectedY = event.getY();
                invalidate();
            }
        }
        if ((userSelectedOption == 1) || (userSelectedOption == 2)) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                initialX = event.getX();
                initialY = event.getY();
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                finalX = event.getX();
                finalY = event.getY();

                if (initialX > finalX) {
                    cornerLeft = finalX;
                    cornerRight = initialX;
                } else {
                    cornerLeft = initialX;
                    cornerRight = finalX;
                }

                if (initialY > finalY) {
                    cornerTop = finalY;
                    cornerBottom = initialY;
                } else {
                    cornerTop = initialY;
                    cornerBottom = finalY;
                }
                invalidate();
            }
            
        }
        return true;
    }
}



