package edu.stanford.cs108.mobiledraw;

import androidx.appcompat.app.AppCompatActivity;
import static edu.stanford.cs108.mobiledraw.CustomViewActivity.*;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void update(View view) {
        if(currentShapeIndex >= 0) {
            EditText editTextFirstField = (EditText) findViewById(R.id.firstField);
            String coordinateX = editTextFirstField.getText().toString();
            EditText editTextSecondField = (EditText) findViewById(R.id.secondField);
            String coordinateY = editTextSecondField.getText().toString();
            EditText editTextThirdField = (EditText) findViewById(R.id.thirdField);
            String coordinateW = editTextThirdField.getText().toString();
            EditText editTextFourthField = (EditText) findViewById(R.id.fourthField);
            String coordinateH = editTextFourthField.getText().toString();
            if(!coordinateX.isEmpty() && !coordinateY.isEmpty() && !coordinateW.isEmpty() && !coordinateH.isEmpty()) {
                float valueX = Float.parseFloat(coordinateX);
                float valueY = Float.parseFloat(coordinateY);
                float valueW = Float.parseFloat(coordinateW);
                float valueH = Float.parseFloat(coordinateH);
                if(userSelectedOption == 0 || userSelectedOption == 3) {
                    shapeCoordinateArray.get(currentShapeIndex).left = valueX;
                    shapeCoordinateArray.get(currentShapeIndex).top = valueY;
                    shapeCoordinateArray.get(currentShapeIndex).right = valueX + valueW;
                    shapeCoordinateArray.get(currentShapeIndex).bottom = valueY + valueH;
                    selectOrErase = true;
                } else {
                    shapeCoordinateArray.remove(currentShapeIndex);
                    shapeBoolean.remove(currentShapeIndex);
                    cornerLeft = valueX;
                    cornerTop = valueY;
                    cornerRight = valueX + valueW;
                    cornerBottom = valueY + valueH;
                }
                CustomViewActivity customViewActivity = (CustomViewActivity) findViewById(R.id.mobileDraw);
                customViewActivity.invalidate();
            }
        }
    }
}