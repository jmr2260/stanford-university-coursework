package edu.stanford.cs108.cityinformation;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.SimpleCursorAdapter;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.database.Cursor;

public class LookupCitiesActivity extends AppCompatActivity {

    SQLiteDatabase cityInformation;
    String[] userInput = {"name","continent","population"}; // From user
    int[] resultView = {R.id.viewCity,R.id.viewContinent,R.id.viewPopulation}; // Back to view by grabbing view ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lookup_cities);

        cityInformation = openOrCreateDatabase("CityInformation",MODE_PRIVATE,null);
    }

    public void onQuery(View view) {
        EditText cityName = (EditText)findViewById(R.id.topField);
        String cityString = cityName.getText().toString();
        if (cityString.isEmpty()) cityString = "";

        EditText continentName = (EditText)findViewById(R.id.middleField);
        String continentString = continentName.getText().toString();
        if (continentString.isEmpty()) continentString = "";

        EditText populationName = (EditText)findViewById(R.id.bottomField);
        String populationString = populationName.getText().toString();
        if (populationString.isEmpty()) populationString = "";

        String lookupString = "";
        if(cityString != "") {
            lookupString += " AND name LIKE \'%" + cityString + "%\'";
        }
        if(continentString != "") {
            lookupString += " AND continent LIKE \'%" + continentString + "%\'";
        }
        if(populationString != "") {
            RadioButton buttonGreaterOrEqual = (RadioButton)findViewById(R.id.greaterOrEqual);
            if(buttonGreaterOrEqual.isChecked()) {
                lookupString += " AND population >= " + populationString;
            } else {
                lookupString += " AND population < " + populationString;
            }
        }

        if(cityString != "" || continentString != "" || populationString != "") {
            lookupString = lookupString.substring(4);
            lookupString = " WHERE" + lookupString;
        }
        lookupString = "SELECT * FROM cities" + lookupString + ";";
        Cursor cityQuery = cityInformation.rawQuery(lookupString,null);

        ListAdapter cityFilter = new SimpleCursorAdapter(
                this, R.layout.activity_filter, cityQuery, userInput, resultView, 0);

        ListView viewResults = (ListView) findViewById(R.id.cityList);
        viewResults.setAdapter(cityFilter);
    }
}