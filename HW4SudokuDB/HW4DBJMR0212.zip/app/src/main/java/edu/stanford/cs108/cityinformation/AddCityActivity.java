package edu.stanford.cs108.cityinformation;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddCityActivity extends AppCompatActivity {

    SQLiteDatabase cityInformation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_city);
        cityInformation = openOrCreateDatabase("CityInformation", MODE_PRIVATE, null);
    }

    public void onSubmit(View view) {
        EditText cityName = (EditText)findViewById(R.id.topField);
        String cityString = cityName.getText().toString();
        if (cityString.isEmpty()) cityString = "";

        EditText continentName = (EditText)findViewById(R.id.middleField);
        String continentString = continentName.getText().toString();
        if (continentString.isEmpty()) continentString = "";

        EditText populationName = (EditText)findViewById(R.id.bottomField);
        String populationString = populationName.getText().toString();
        if (populationString.isEmpty()) populationString = "";

        if(cityString != "" && continentString != "" && populationString != "") {
            String insertData = "INSERT INTO cities VALUES (\'" + cityString + "\', \'" + continentString + "\', " + populationString + ", NULL);";
            cityInformation.execSQL(insertData);

            Context cityAdded = getApplicationContext();
            Toast toast = Toast.makeText(cityAdded, cityString + " Added ", Toast.LENGTH_SHORT);
            View toastView = toast.getView();
            toastView.setBackgroundColor(Color.LTGRAY);
            toast.show();
        }
    }
}